/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guessNumber;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Date;

/**
 *
 * @author Tony
 */
public class Attempt {

    public Date date;
    public int operator;
    public double loans;
    public double total;
    String name;
    NumberFormat formatter = NumberFormat.getCurrencyInstance();
    DecimalFormat df = new DecimalFormat("#.##");
    DecimalFormat def = new DecimalFormat("#.00");

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public int getOperator() {
        return operator;
    }

    public void setOperator(int operator) {
        this.operator = operator;
    }

    public String getLoans() {
        return formatter.format(loans);
    }

    public void setLoans(double loans) {
        this.loans = loans;
    }

    public String getTotal() {
        return formatter.format(total);
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    

}
