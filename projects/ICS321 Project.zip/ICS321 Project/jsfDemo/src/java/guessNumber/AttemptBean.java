/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guessNumber;

import javax.inject.Named;
import javax.enterprise.context.Dependent;

import guessNumber.Attempt;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import javax.annotation.Resource;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.sql.DataSource;
import java.util.Date;

/**
 *
 * @author Tony
 */
@ManagedBean(name = "Attempt")
@SessionScoped
public class AttemptBean {

    @Resource(name = "jdbc/ics321")
    private DataSource ds;

    public List<Attempt> getAttemptList() throws SQLException {
        Connection conn = null;
        String url = "jdbc:derby://localhost:1527/ics321";
        String dbName = "ics321";
        String driver = "org.apache.derby.jdbc.ClientDriver";
        String userName = "DBUSER";
        String password = "ics321";
        List<Attempt> list = new ArrayList<Attempt>();
        UserNumberBean ted = new UserNumberBean();
        String date;
        

        
        try {
            Class.forName(driver).newInstance();
            conn = DriverManager.getConnection(url, userName, password);
            Statement s = conn.createStatement();
            
            date = ted.getHold();
           

            
            //get data from database
            //SELECT * FROM DBUSER.CASH WHERE DAYS = '2016-11-04';
            s.execute("select days, operator, totalcash from cash where days = '2016-11-04'");
            ResultSet result = s.getResultSet();

            while (result.next()) {
                Attempt a = new Attempt();

                a.setDate(result.getDate("days"));
                a.setOperator(result.getInt("operator"));
                a.setTotal(result.getDouble("totalcash"));

                //store all data into a List
                list.add(a);
            }
            return list;

        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return list;
    }
}
