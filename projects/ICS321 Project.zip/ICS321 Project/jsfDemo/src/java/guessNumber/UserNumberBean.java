package guessNumber;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.annotation.Resource;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;
import java.util.Date;

/**
 *
 * @author nbuser
 */
@ManagedBean(name = "UserNumberBean")
@SessionScoped
public class UserNumberBean implements Serializable {

    Integer randomInt;
    Integer aperator;
    Integer lperator;
    Integer dperator;
    Integer cperator;
    String name;
    Double loans;
    Double totalcash;
    String response;
    Date day;
    String hold;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public String getHold() {
        return hold;
    }

    public void setHold(String hold) {
        this.hold = hold;
    }

    @Resource(name = "jdbc/ics321")
    private DataSource ds;

    /**
     * Creates a new instance of UserNumberBean
     */
    public UserNumberBean() {
        Random randomGR = new Random();
        randomInt = new Integer(randomGR.nextInt(10));
    }

    public Integer getAperator() {
        return aperator;
    }

    public Double getLoans() {
        return loans;
    }

    public void setLoans(Double loans) {
        this.loans = loans;
    }

    public Double getTotalcash() {
        return totalcash;
    }

    public void setTotalcash(Double totalcash) {
        this.totalcash = totalcash;
    }

    public Date getDay() {
        return day;
    }

    public void setDay(Date day) {
        SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd");        
        hold = fmt.format(day);
        this.day = day;
    }

    public Integer getDperator() {
        return dperator;
    }

    public void setDperator(Integer dperator) {
        this.dperator = dperator;
        Connection conn = null;
        String url = "jdbc:derby://localhost:1527/ics321";
        String dbName = "ics321";
        String driver = "org.apache.derby.jdbc.ClientDriver";
        String userName = "DBUSER";
        String password = "ics321";

        try {
            Class.forName(driver).newInstance();
            conn = DriverManager.getConnection(url, userName, password);
            Statement s = conn.createStatement();

            //operator=119;
            //loans=600.0;
            //totalcash=1562.32;
            
            System.out.print(this.loans + " " + dperator + " " + this.hold);
            
            s.execute("UPDATE Cash SET totalcash = totalcash - "+this.loans+" WHERE Operator = "+dperator+" AND Days = '"+this.hold+"'");
        } catch (Exception e) {

        }
    }
    
    public Integer getLperator() {
        return lperator;
    }
    
    public Integer getCperator() {
        return cperator;
    }

    public void setLperator(Integer lperator) {
        this.lperator = lperator;
        Connection conn = null;
        String url = "jdbc:derby://localhost:1527/ics321";
        String dbName = "ics321";
        String driver = "org.apache.derby.jdbc.ClientDriver";
        String userName = "DBUSER";
        String password = "ics321";

        try {
            Class.forName(driver).newInstance();
            conn = DriverManager.getConnection(url, userName, password);
            Statement s = conn.createStatement();

            //operator=119;
            //loans=600.0;
            //totalcash=1562.32;
            
            s.execute("UPDATE Cash SET totalcash = totalcash + "+this.loans+" WHERE Operator = "+lperator+" AND Days = '"+this.hold+"'");
        } catch (Exception e) {

        }
    }

    public void setAperator(Integer aperator) {
        Connection conn = null;
        String url = "jdbc:derby://localhost:1527/ics321";
        String dbName = "ics321";
        String driver = "org.apache.derby.jdbc.ClientDriver";
        String userName = "DBUSER";
        String password = "ics321";

        //test
        this.aperator = aperator;

        try {
            Class.forName(driver).newInstance();
            conn = DriverManager.getConnection(url, userName, password);
            Statement s = conn.createStatement();

            //operator=119;
            //loans=600.0;
            //totalcash=1562.32;
            s.execute("INSERT INTO CASH (DAYS, OPERATOR, totalcash)\n"
                    + "SELECT '"+this.hold+"', "+this.aperator+", "+this.totalcash+"\n"
                    + "  FROM SYSIBM.SYSDUMMY1\n"
                    + " WHERE NOT EXISTS (SELECT 1 \n"
                    + "                     FROM CASH \n"
                    + "                    WHERE OPERATOR = "+this.aperator+"\n"
                    + "                      AND dAYS = '"+this.hold+"')");
        } catch (Exception e) {

        }
    }
    
    public void setCperator(Integer cperator) {
        this.cperator = cperator;
        Connection conn = null;
        String url = "jdbc:derby://localhost:1527/ics321";
        String dbName = "ics321";
        String driver = "org.apache.derby.jdbc.ClientDriver";
        String userName = "DBUSER";
        String password = "ics321";

        try {
            Class.forName(driver).newInstance();
            conn = DriverManager.getConnection(url, userName, password);
            Statement s = conn.createStatement();

            //operator=119;
            //loans=600.0;
            //totalcash=1562.32;
            
            
            
            s.execute("UPDATE dbuser.cashier SET Name = '"+this.name+"' WHERE Operator = "+cperator+"");
        } catch (Exception e) {

        }
    }
    
        public List<Attempt> getAttemptList() throws SQLException {
        Connection conn = null;
        String url = "jdbc:derby://localhost:1527/ics321";
        String dbName = "ics321";
        String driver = "org.apache.derby.jdbc.ClientDriver";
        String userName = "DBUSER";
        String password = "ics321";
        List<Attempt> list = new ArrayList<Attempt>();
        

        
        try {
            Class.forName(driver).newInstance();
            conn = DriverManager.getConnection(url, userName, password);
            Statement s = conn.createStatement();
            
            String date = this.hold;
           

            
            //get data from database
            //SELECT DBUSER.CASHIER.OPERATOR, NAME, DAYS, TOTALCASH FROM DBUSER.CASHIER JOIN DBUSER.CASH ON CASH.OPERATOR = CASHIER.OPERATOR;
            s.execute("select cashier.operator, name, days, totalcash from cashier join cash on cash.operator = cashier.operator where days = '"+date+"' order by operator");
            ResultSet result = s.getResultSet();

            while (result.next()) {
                Attempt a = new Attempt();

                a.setOperator(result.getInt("operator"));
                a.setName(result.getString("name"));
                a.setDate(result.getDate("days"));
                a.setTotal(result.getDouble("totalcash"));

                //store all data into a List
                list.add(a);
            }
            return list;

        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return list;
    }
    
        
        public List<Attempt> getCashierList() throws SQLException {
        Connection conn = null;
        String url = "jdbc:derby://localhost:1527/ics321";
        String dbName = "ics321";
        String driver = "org.apache.derby.jdbc.ClientDriver";
        String userName = "DBUSER";
        String password = "ics321";
        List<Attempt> list = new ArrayList<Attempt>();
        

        
        try {
            Class.forName(driver).newInstance();
            conn = DriverManager.getConnection(url, userName, password);
            Statement s = conn.createStatement();
            
            String date = this.hold;
           

            
            //get data from database
            //SELECT DBUSER.CASHIER.OPERATOR, NAME, DAYS, TOTALCASH FROM DBUSER.CASHIER JOIN DBUSER.CASH ON CASH.OPERATOR = CASHIER.OPERATOR;
            s.execute("select operator, name from cashier order by operator");
            ResultSet result = s.getResultSet();

            while (result.next()) {
                Attempt a = new Attempt();

                a.setOperator(result.getInt("operator"));
                a.setName(result.getString("name"));

                //store all data into a List
                list.add(a);
            }
            return list;

        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return list;
    }
    
}
